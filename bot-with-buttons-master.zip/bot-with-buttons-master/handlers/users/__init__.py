from .menu import dp

__all__ = ["dp"]
