BOT_TOKEN = "942352703:AAHezudMmJq-x6JiVMtZ_NywAc1c6wWAZoE"  # Your token
